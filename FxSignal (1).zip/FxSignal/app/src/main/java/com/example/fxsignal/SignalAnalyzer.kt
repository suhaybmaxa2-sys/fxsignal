package com.example.fxsignal

/** Akhriyaa shamaadaha cagaarka/guduudka ah ee sawirka, kadibna BUY / SELL / WAIT ayuu soo saaraa. */
object SignalAnalyzer {
    data class Candle(val x: Int, val top: Int, val bottom: Int, val green: Boolean)
    data class Result(val signal: String, val x: Int, val y: Int, val note: String)

    private fun isGreen(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return g > 130 && g > r + 40 && g > b + 40
    }
    private fun isRed(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return r > 150 && r > g + 60 && r > b + 60
    }

    fun analyze(px: IntArray, w: Int, h: Int): Result {
        val y0 = (h * 0.12).toInt(); val y1 = (h * 0.88).toInt(); val x1 = (w * 0.92).toInt()
        val candles = ArrayList<Candle>()
        var curColor = 0; var curTop = 0; var curBot = 0; var curX = 0; var curW = 0

        fun flush() {
            if (curColor != 0 && curBot - curTop >= 3) candles.add(Candle(curX, curTop, curBot, curColor == 1))
            curColor = 0; curW = 0
        }

        for (x in 0 until x1) {
            var cg = 0; var cr = 0; var tg = Int.MAX_VALUE; var bg = 0; var tr = Int.MAX_VALUE; var br = 0
            for (y in y0 until y1) {
                val c = px[y * w + x]
                if (isGreen(c)) { cg++; if (y < tg) tg = y; if (y > bg) bg = y }
                else if (isRed(c)) { cr++; if (y < tr) tr = y; if (y > br) br = y }
            }
            val col = if (cg >= 2 && cg >= cr) 1 else if (cr >= 2) 2 else 0
            if (col == 0) { flush(); continue }
            val t = if (col == 1) tg else tr; val b = if (col == 1) bg else br
            if (col != curColor) { flush(); curColor = col; curTop = t; curBot = b; curX = x }
            else { if (t < curTop) curTop = t; if (b > curBot) curBot = b }
            curX = (curX + x) / 2
        }
        flush()

        if (candles.size < 10) return Result("WAIT", w / 2, h / 3, "Shamaado kugu filan ma arkin. Hubi chart-ka (cagaar/guduud).")
        val last = candles.takeLast(10)
        val mids = last.map { -((it.top + it.bottom) / 2f) }   // kor = qiime sare
        val fast = mids.takeLast(3).average(); val slow = mids.average()
        val range = (last.maxOf { it.bottom } - last.minOf { it.top }).toFloat()
        val diff = fast - slow; val thr = range * 0.08
        val greens = last.takeLast(3).count { it.green }
        val lc = last.last()
        return when {
            diff > thr && greens >= 2 -> Result("BUY", lc.x, lc.bottom + 30, "Jihada kor ayay u socotaa")
            diff < -thr && greens <= 1 -> Result("SELL", lc.x, lc.top - 120, "Jihada hoos ayay u socotaa")
            else -> Result("WAIT", lc.x, lc.top - 120, "Jiho cad ma jirto")
        }
    }
}
