package com.example.fxsignal

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var button: TextView? = null
    private var arrow: TextView? = null
    @Volatile private var want = false
    private var sw = 0; private var sh = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fx", "FX Signal", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "fx").setContentTitle("FX Signal wuu shaqeynayaa")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION") val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val m = resources.displayMetrics; sw = m.widthPixels; sh = m.heightPixels

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, ui)
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay("fx", sw, sh, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_AUTO_MIRROR, reader!!.surface, null, null)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!want) { img.close(); return@setOnImageAvailableListener }
            want = false
            val p = img.planes[0]; val rowPx = p.rowStride / p.pixelStride
            val bmp = Bitmap.createBitmap(rowPx, sh, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(p.buffer); img.close()
            val px = IntArray(sw * sh)
            bmp.getPixels(px, 0, sw, 0, 0, sw, sh)
            val res = SignalAnalyzer.analyze(px, sw, sh)
            ui.post { show(res) }
        }, ui)
        addButton()
        return START_NOT_STICKY
    }

    private fun lp(x: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.let { 0 },
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun addButton() {
        val b = TextView(this).apply {
            text = "SCAN"; setTextColor(Color.WHITE); textSize = 14f; setPadding(36, 24, 36, 24)
            setBackgroundColor(Color.parseColor("#CC1565C0"))
        }
        val params = lp(20, sh / 3)
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = params.x; sy = params.y; moved = false }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    params.x = sx + (e.rawX - dx).toInt(); params.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(v, params)
                }
                android.view.MotionEvent.ACTION_UP -> if (!moved) scan()
            }
            true
        }
        wm.addView(b, params); button = b
    }

    private fun scan() {
        removeArrow()
        button?.visibility = View.INVISIBLE
        ui.postDelayed({ want = true }, 250)
        ui.postDelayed({
            if (want) { want = false; button?.visibility = View.VISIBLE; toast("Isku day mar kale") }
        }, 2500)
    }

    private fun show(r: SignalAnalyzer.Result) {
        button?.visibility = View.VISIBLE
        val (label, color) = when (r.signal) {
            "BUY" -> "▲ BUY" to "#E600A050"
            "SELL" -> "▼ SELL" to "#E6D32F2F"
            else -> "• WAIT" to "#E6616161"
        }
        val a = TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 26f; setPadding(40, 20, 40, 20)
            setBackgroundColor(Color.parseColor(color)); setOnClickListener { removeArrow() }
        }
        val p = lp((r.x - 120).coerceIn(0, sw - 300), r.y.coerceIn(0, sh - 200))
        p.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.addView(a, p); arrow = a
        toast(r.note)
        ui.postDelayed({ removeArrow() }, 8000)
    }

    private fun toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show()
    private fun removeArrow() { arrow?.let { try { wm.removeView(it) } catch (_: Exception) {} }; arrow = null }

    override fun onDestroy() {
        removeArrow()
        button?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
